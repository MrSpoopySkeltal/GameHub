package com.gamehub.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {
    
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("pageTitle", "GameHub - Your Ultimate Gaming Destination");
        return "index";
    }
    
    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("pageTitle", "Login - GameHub");
        return "auth/login";
    }
    
    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("pageTitle", "Register - GameHub");
        return "auth/register";
    }
    
    @GetMapping("/products")
    public String products(Model model) {
        model.addAttribute("pageTitle", "Products - GameHub");
        return "products/index";
    }
    
    @GetMapping("/user-management")
    public String userManagement(Model model,
                               @RequestParam(required = false) String username) {
        model.addAttribute("pageTitle", "User Management - GameHub");
        model.addAttribute("searchUsername", username != null ? username : "");
        return "admin/user-management";
    }
}
